$(document).ready(function()
{
		$("img").mouseenter(function()
		{ 
			$(this).animate(
			{

			left: '350px',
			height:'400px',
			width:'400px'

			});


		});

		$("img").mouseleave(function()
		{ $(this).animate(
			{

			height:'300px',
			width:'300px'

			});

		});



	
});


function cartCounter()
{
	if (typeof(Storage) !== "undefined") 
	{
		if (sessionStorage.clickcount)
		{
			sessionStorage.clickcount = Number(sessionStorage.clickcount)+1;
			
		}
	
		else 
		{
			sessionStorage.clickcount = 1;
		}
		document.getElementsByTagName("button").innerHTML = "You have added " + sessionStorage.clickcount + " album(s) to your cart. ";
	}

}

