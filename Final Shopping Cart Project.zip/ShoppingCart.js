
//some global variables and constants
arrItemsAbletToBeChecked = [];
arrItemToRemove = [];
const FIX_TAXED_RATE = 0.06; //gwinette county sales tax rate

//the postion of these in array
const QTY_POSITION = 0;
const ITEM_NAME_POSITION = 1;
const PRICE_POSITION = 2;
const TOTAL_COST_POSITION = 3;

//Adds the item specified in obj to the cart
function addToCart(obj)
{
	//declare some local variables
	var bAlreadyInList = false;
	var storageItem;
	var itemList; // = [];
	//default the quantity to 1
	var qty;
	var name;
	var price;
	var costIncludingTax;
	var totalCostWithOutTax;

	qty = 1;

	//get the name of the item
	name = obj.siblings(".itemTitle").text();

	//get the price, convert it to a number by removing any non-numeric character
	price = Number(obj.siblings(".itemCost").text().replace(/[^0-9\.]+/g,"")).toFixed(2); // * 1.00;
	
	//calcualte the cost with tax
	costIncludingTax = (qty * price) * FIX_TAXED_RATE;

	//calculate the total cost
	totalCostWithOutTax = Number((qty * price)).toFixed(2);

	//store this as a objec in our array
	var item =[qty, name, price, totalCostWithOutTax];
	
	//make sure local storage capability is enabled 
	if (typeof(Storage) !== "undefined") 
	{
		storageItem = sessionStorage.getItem("itemList");

		//check to see if we already have items in the cart, 
		if(!storageItem)
			itemList = []; //no items, set it to empty array
		else
		{
			//since we store our cart items using JSON format convert from JSON
			itemList = JSON.parse(storageItem);
			//just a safety precaution, to check again to see if we already had items in the cart
			if(!itemList)
				itemList = []; //no items, set it to empty array
		}

	} 
	else 
	{
		alert("Sorry! No Web Storage support..");
		return;
	}	

	//check to see if the new item is already in our itemList, if so increment the quantity for this item and recalculate cost
	var nLen = itemList.length;
	for (var i = 0; i < nLen; i++) 
	{
		var tmpItem = itemList[i];

		if ( tmpItem[ITEM_NAME_POSITION] === name )
		{
			bAlreadyInList = true;

			//increment the qty
			qty = parseInt(tmpItem[QTY_POSITION]) + 1;
			//get the price, convert it to a number by removing any non-numeric character
			price = Number(tmpItem[PRICE_POSITION]).toFixed(2); // * 1.00;
			
			//calculate the total cost
			totalCostWithOutTax = (qty * price);

			itemList[i][QTY_POSITION] = qty;			
			itemList[i][PRICE_POSITION] = price;						
			itemList[i][TOTAL_COST_POSITION] = totalCostWithOutTax.toFixed(2);			

			break;
		}
	} 

	//if not already in the list add it to the list.
	if( bAlreadyInList == false) 
	{
			//new item was not in the itemList so add it 
		itemList.push(item);

	}
	
	//write the itemList contents to the console	
	console.log(itemList);
	
	//convert itemlist contents to a string
	storageItem = JSON.stringify(itemList);
	
	//store our itemList in local storage 
	sessionStorage.clear();
	sessionStorage.setItem("itemList", storageItem);

	//since we have somethin in the cart, enable the show button
	doDisableBtnShowItemsInCart(false);

	//recalculate the totals
	calcTotal();
}

function calcTotal()
{
	var totalNumberOfItemsInCart  = 0;
	var total = 0;
	var keyList;
	var storageItem;
	var itemList; // = [];

	//get the itemList from storage
	storageItem = sessionStorage.getItem("itemList");

	//check to make sure that something was there
	if(!storageItem) {

		storageItem = []; //no items, set it to empty array
	}
	else {
		//convert from JSON
		keyList = JSON.parse(storageItem);

		for (var i = keyList.length - 1; i >= 0; i--) 
		{
			totalNumberOfItemsInCart += parseInt(keyList[i][QTY_POSITION]);

			total += keyList[i][QTY_POSITION] * keyList[i][PRICE_POSITION];
		}
		
	}

	//update the Cart Number 
	if($("#totalItemsInCart"))
	{
		if(totalNumberOfItemsInCart > 0)
			$("#totalItemsInCart").html("&nbsp;-&nbsp;" + totalNumberOfItemsInCart.toString() + "&nbsp;items");
		else
			$("#totalItemsInCart").html("&nbsp;-&nbsp;Empty");
	}

	console.log(total);
	return totalNumberOfItemsInCart;

}

function showItemsInCart()
{

	var keyList;
	var qty;
	var name;
	var price;
	var tax;
	var total;
	var qtyTotal = 0;
	var priceTotal = 0.00;
	var taxTotal = 0.00;
	var grandTotal = 0.00;
	var row;
	var div;
	var checkButtonCol;
	var checkButton;
	var qtyCol;
	var itemCol;
	var priceCol;
	var taxCol;
	var totalCol;

	var storageItem;

	//get the itemList from storage
	storageItem = sessionStorage.getItem("itemList");

	//check to make sure that something was there
	if(!storageItem) {
		//since the cart is empty remove any existing items the Carts table
		$("#myShoppingCartBody").children().remove();
		$("#sumQty").html("");
		$("#sumPrice").html("");
		//$("#sumTaxes").html("6%");
		$("#sumTotals").html("");

		$("#grandSumQty").html("");
		$("grandSumPrice").html("");
		$("#grandSumTaxes").html("6%");
		$("#grandSumTotals").html("");
	
	}
	else {
		$("#myShoppingCartBody").children().remove();

		//convert from JSON
		keyList = JSON.parse(storageItem);

		//convert from JSON
		keyList = JSON.parse(storageItem);

		//write the itemList to the console
		console.log(keyList);

		//Use jQuery to get the element whose id is myList
		
		for (var i = keyList.length - 1; i >= 0; i--) 
		{
			name = keyList[i][ITEM_NAME_POSITION];
			qty = keyList[i][QTY_POSITION];
			price = Number(keyList[i][PRICE_POSITION]).toFixed(2); // * 1.00;
			total = Number((qty * price)).toFixed(2);

			qtyTotal += qty;
			priceTotal = Number(Number(priceTotal) + Number(price)).toFixed(2);

			//quan = itemList[name][1];
			row = document.createElement("tr");
			
			checkButtonCol = document.createElement("td");
			//div = document.createElement("div");
			//div.id ="shoppingCartChbDiv";
			//checkButtonCol.id = "chkTd";
			checkButton = document.createElement("input");
			checkButton.type = "checkbox";
			checkButton.id = "checkBoxID" +i;
			checkButton.className = "cartCheckBoxClass";

			//add a property to the checkButton to contain the item name
			checkButton.itemName = name;
			//checkButton.addEventListener('click', doCheckItem);
			//specify the function that should be called when the check box is clicked
			checkButton.onclick= function () {
									if(this.checked) 
										addItemToRemoveList(this); 
									else 
										removeItemFromRemoveList(this);
								};

			checkButtonCol.appendChild(checkButton);
			qtyCol = document.createElement("td");
			qtyCol.className="numericValue";
			//$("#myShoppingCartBody > td").addClass("numericValue");
			itemCol = document.createElement("td");
			priceCol = document.createElement("td");
			taxCol = document.createElement("td");
			totalCol = document.createElement("td");
			//qtyCol.addClass('numericValue');

			qtyCol.innerText = qty;
			itemCol.innerText = name;
			priceCol.innerText = price;
			totalCol.innerText = total; //totalAmtWithOutTax;
			 
			row.appendChild(checkButtonCol);
			row.appendChild(qtyCol);
			row.appendChild(itemCol);
			row.appendChild(priceCol);
			row.appendChild(taxCol);
			row.appendChild(totalCol);
			//$("#myShoppingCartTable > tbody").append(row);
			document.getElementById("myShoppingCartBody").appendChild(row);
		
		} //for (var i = keyList.length - 1; i >= 0; i--)
		$("#sumQty").html(qtyTotal);
		$("#sumPrice").html(priceTotal);
		//$("#sumTaxes").html("6%");
		grandTotal = Number((Number(qtyTotal) * Number(priceTotal))).toFixed(2);
		$("#sumTotals").html( grandTotal);

		$("#grandSumQty").html(qtyTotal);
		$("grandSumPrice").html(priceTotal);
		$("#grandSumTaxes").html("6%");
		grandTotal = Number((Number(qtyTotal) * Number(priceTotal)) + ((Number(qtyTotal) * Number(priceTotal))* Number(FIX_TAXED_RATE).toFixed(2))).toFixed(2);
		$("#grandSumTotals").html( grandTotal);

		if(calcTotal <= 100){alert("You Must Pay with cash")} else{alert("You must pay with cash")}

	} //if(storageItem)
	
	calcTotal();
	doDisableBtnShowItemsInCart(true);
	doDisableBtnRemoveFromCart(true);
	$("#chkboxCheckAllInCart").prop("disabled",false);
	$("#chkboxCheckAllInCart").prop("checked",false);
	$("#chkboxUncheckAllInCart").prop("disabled",true);
	$("#chkboxUncheckAllInCart").prop("checked",false);

}

function removeItemFromRemoveList(theChkObjOfTheItem)
{
	var tmpObj;

	//start at the end of the array since we are using slice to remove elements and 
	//thus the length of the array will change each time we call slice 
	for(var i = arrItemToRemove.length-1; i >=0; i--) {
		tmpObj = arrItemToRemove[i];
		if(tmpObj.itemName == theChkObjOfTheItem.itemName ) {
			theChkObjOfTheItem.checked = false;
			arrItemToRemove.splice(i,1);
		}
	}

	if(arrItemToRemove.length < 1)
		doDisableBtnRemoveFromCart(true);
	else
		doDisableBtnRemoveFromCart(false);

}

function addItemToRemoveList(chkObj)
{
	
	arrItemToRemove.push(chkObj);
	doDisableBtnRemoveFromCart(false);

}

//where 
//when action = true - check all
//when action = false - uncheck all
function doCheckOrUnCheckAll(action)
{
	var tmpObj;
	var storeageItem;


	if(action == true) {
		//$(".cartCheckBoxClass").prop("checked", action);
		$(".cartCheckBoxClass").each(function() {
			$(this).prop("checked", action);
			addItemToRemoveList($(this));
		});


		doDisableBtnRemoveFromCart(!action);
		$("#chkboxUncheckAllInCart").prop("checked",false);
		$("#chkboxUncheckAllInCart").prop("disabled",false);
		$("#chkboxCheckAllInCart").prop("disabled",true);
		
	}
	else {
		//find all checkbox in the cart and unheck them

		$(".cartCheckBoxClass").each(function() {
			$(this).prop("checked", action);
			removeItemFromRemoveList($(this));
		});

		//$(".cartCheckBoxClass").prop("checked", action);
		doDisableBtnRemoveFromCart(!action);
		$("#chkboxUncheckAllInCart").prop("disabled",true);
		$("#chkboxUncheckAllInCart").prop("checked",true);
		$("#chkboxCheckAllInCart").prop("checked",false);
		$("#chkboxCheckAllInCart").prop("disabled",false);
	}

}


function removeFromCart()
{
	//this function will move items from the cart.
	//only those items whose checkbox is checked will be removed.
	var keyList;
	var storageItem;
	var objTheChkObj;

	//if nothing to remove, exit now
	if( arrItemToRemove.length < 1 )
		return;

	//get the itemList from storage
	storageItem = sessionStorage.getItem("itemList");

	//if nothing in storage exit now
	if(!storageItem)
		return;

	//convert from JSON
	keyList = JSON.parse(storageItem);
	//for each item to be removed, remove it from the storage cart
	for(var i = arrItemToRemove.length-1; i >= 0; i--) {
		
		objTheChkObj = arrItemToRemove[i];

		//start at the end of the array since we are using slice to remove elements and 
		//thus the length of the array will change each time we call slice 

		for (var j = keyList.length-1; j >=0; j--) {
			if(objTheChkObj.itemName === keyList[j][ITEM_NAME_POSITION] )
			{
				keyList.splice(j,1);
			    break;
		   }
		}
		
	}

	//convert itemlist contents to a string
	storageItem = JSON.stringify(keyList);
	sessionStorage.clear();

	if(keyList.length > 0) {
		//store our itemList in local storage 
		sessionStorage.setItem("itemList", storageItem);
	}

	//recalculate the totals
	calcTotal();

	//call this to refresh the page
	showItemsInCart();

	//empty the array and 
	//uncheck all checkbox on the item page.
	//start at the end of the array since we are using slice to remove elements and 
	//thus the length of the array will change each time we call slice 
	/*for(var i = arrItemToRemove.length-1; i >= 0; i--) {

		//make sure the button is no longer checked
		objTheChkObj = arrItemToRemove[i];
		objTheChkObj[0].checked = false;	
	}
	*/

	arrItemToRemove =[];

			//since no more items in the cart or list disable the buttons
		doDisableBtnRemoveFromCart(true);
		doDisableBtnShowItemsInCart(true);

}

function showMainPage() {
	$("#shoppingItems").hide();
	$("#shoppingCart").hide();
	//document.getElementById("shoppingCart").style.display = "none";
	$("#mainPage").show();

}

function showShoppingItems() {
	//document.getElementById("shoppingCart").style.display = "none";
	$("#mainPage").hide();
	$("#shoppingCart").hide();
	$("#shoppingItems").show();
}

function showShoppingCart() {
	$("#shoppingItems").hide();
	$("#mainPage").hide();
	doDisableBtnShowItemsInCart(false);
	doDisableBtnRemoveFromCart(true);
	showItemsInCart();

	$("#shoppingCart").show();

	//document.getElementById("shoppingCart").style.display = "block";
}

//where action is true or false
function doDisableBtnRemoveFromCart(action) {
	
		$("#btnRemoveFromCart").prop("disabled",action);
		$("#chkboxCheckAllInCart").prop("disabled",action);
		$("#chkboxUncheckAllInCart").prop("disabled",action);
	
}
function doDisableBtnShowItemsInCart(action) {
	
		$("#btnShowItemsInCart").prop("disabled",action);
}

//this function does some intinalization stuff
//For example it makes sure the sessionStorage is empty
function doInitialization()
{

	//do something on mouse enter event
	$("img").mouseenter(function()
	{ 
		$(this).animate(
		{

		left: '200px',
		height:'200px',
		width:'200px'


		});
	


	});

	//do sonmething on mouse leave event
	$("img").mouseleave(function()
	{ $(this).animate(
		{

		height:'100px',
		width:'100px'

		});

	});

	//if no items are in the cart disable the btnShowItemsInCart button
	if(calcTotal() < 1) {
		doDisableBtnShowItemsInCart(true);
		doDisableBtnRemoveFromCart(true);
	}
	else {
		doDisableBtnShowItemsInCart(false);

		//check to see if any items are checked to be removed, if enable the RemoveFromCart button
	}

	//show the main page
	showMainPage();

}

